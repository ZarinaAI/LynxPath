---
name: Adapter proposal
title: "[Adapter] Prototype mapping into the capacity-signal schema"
about: Propose or implement a synthetic/example adapter
labels: "adapter,interoperability"
---

## Source format

Describe the public/example format you want to map.

## Mapping

List which source fields map to travel, ED delay, capabilities, resource delays, freshness and confidence.

## Safety

Use synthetic or public example data only. Do not include credentials, patient data or confidential hospital data.
