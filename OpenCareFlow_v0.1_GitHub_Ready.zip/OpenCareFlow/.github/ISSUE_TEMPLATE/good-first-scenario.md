---
name: Good first issue — scenario
title: "[Scenario] Add a reproducible synthetic capacity scenario"
about: Add a small validated scenario and one regression test
labels: "good first issue,scenario"
---

## Goal

Add a deterministic synthetic scenario under `scenarios/` that demonstrates one operational bottleneck.

## Done when

- [ ] Scenario validates against `schema/scenario.schema.json`
- [ ] No real patient or hospital data
- [ ] At least one regression assertion added
- [ ] README or scenario description explains the behavior
